# Read Sequencer

## Overview

Read Sequencer is a test phyton package to simulate Sequencing. 
It reads fasta files, simulate sequencing and writes the resulting sequences into a new fasta file.


## Installation

To install the latest release from GitHub:

```
if (!requireNamespace("remotes", quietly = TRUE))
    install.packages("remotes")
remotes::install_github(".../Read_Sequencer")

```

## Contributors and Contact Information

Christoph Harmel - christoph.harmel@unibas.ch  
Michael Sandholzer - michael.sandholzer@unibas.ch  
Clara Serger - c.serger@unibas.ch  

