from setuptools import setup

setup(
    name='read_sequencer',
    version='',
    packages=['read_sequencer_package'],
    url='',
    license='MIT',
    author='harmelc',
    author_email='',
    description=''
)
