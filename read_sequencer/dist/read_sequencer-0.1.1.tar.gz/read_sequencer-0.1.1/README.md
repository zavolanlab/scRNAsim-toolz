# Read Sequencer

## Overview

Read Sequencer is a test python package to simulate sequencing. 
It reads fasta files, simulate sequencing with specified read length and writes the resulting sequences into a new fasta file.


## Installation from PyPI

Read_Sequencer requires Python 3.6 or later.

Install Read_Sequencer from PyPI using:

```
pip install Read_Sequencer

```

## Contributors and Contact Information

Christoph Harmel - christoph.harmel@unibas.ch  
Michael Sandholzer - michael.sandholzer@unibas.ch  
Clara Serger - c.serger@unibas.ch  

